# Sketch2code > 2023-01-28 2:39pm
https://universe.roboflow.com/dataset-sxe10/sketch2code-8c5ut

Provided by a Roboflow user
License: CC BY 4.0

